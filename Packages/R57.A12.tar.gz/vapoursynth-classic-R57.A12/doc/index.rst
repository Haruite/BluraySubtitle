Welcome to `VapourSynth-Classic <https://amusementclub.github.io/doc/>`_’s documentation!
=========================================================================================

Contents:

.. toctree::
   :maxdepth: 3

   introduction
   installation
   gettingstarted
   pythonreference  
   functions
   output
   applications
   avisynthcomp
   includedplugins
   apireference


Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
